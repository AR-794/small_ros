import RPi.GPIO as GPIO
import time

# ----------------------------
# GPIO Configuration
# ----------------------------
LED_PIN = 2  # Use the GPIO pin connected to your LED
BLINK_INTERVAL = 0.5  # seconds

GPIO.setmode(GPIO.BCM)
GPIO.setup(LED_PIN, GPIO.OUT)

try:
    while True:
        GPIO.output(LED_PIN, GPIO.HIGH)
        time.sleep(BLINK_INTERVAL)
        GPIO.output(LED_PIN, GPIO.LOW)
        time.sleep(BLINK_INTERVAL)
except KeyboardInterrupt:
    pass
finally:
    GPIO.cleanup()
