document.addEventListener("DOMContentLoaded", () => {
  const socket = io({ transports: ["websocket"] });
  // Chart data
  const labels = [
    "06:00",
    "07:00",
    "08:00",
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "13:00",
    "14:00",
    "15:00",
    "16:00",
    "17:00",
    "18:00",
    "19:00"
  ];

  let angleData = [
    -45, -45, -30, -15, 
    0, 15, 30, 15, 
    10, 5 , 0 , -15 , -30 , -45
  ];

  let powerData = [
    0.5, 1, 2, 
    4, 4.5, 5, 5, 
    5, 5, 4.5, 4, 2, 1, 0.5
  ];

    let irradiationData = [
    0, 400, 800, 
    1000, 1200, 1200, 1200, 
    1200, 1200, 1000, 600, 400, 300, 0
  ]; // 👈 NEW dataset

  // Chart initialization
  const ctx = document.getElementById("systemGraph").getContext("2d");

  // Chart initialization
  let systemChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: labels.slice(
        labels.indexOf("06:00"),
        labels.indexOf("19:00") + 1
      ),
      datasets: [
        {
          label: "Angle (°)",
          data: new Array(9).fill(null), // placeholders from 09 to 17
          yAxisID: "y",
          borderColor: "rgb(40, 167, 69)",
          backgroundColor: "rgba(40, 167, 69, 0.2)",
          tension: 0.1,
          fill: true,
        },
        {
          label: "Power (mW)",
          data: new Array(9).fill(null),
          yAxisID: "y1",
          borderColor: "rgb(255, 99, 132)",
          backgroundColor: "rgba(255, 99, 132, 0.2)",
          tension: 0.3,
          fill: false,
        },
         {
          label: "Irradiation (W/m²)",   // 👈 NEW dataset
          data: new Array(9).fill(null),
          yAxisID: "y2",
          borderColor: "orange",
          backgroundColor: "rgba(255,165,0,0.2)",
          tension: 0.3,
          fill: false,
        }
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      //  animation: false,  

  
      scales: {
        x: {
          type: "category", // Use "category" for string labels!
          title: { display: true, text: "Time (hours)" },
          ticks: {
            autoSkip: false, // Prevents Chart.js from skipping labels
          },
          display: true,
        },
        y: { min: -50, max: 50, title: { display: true, text: "Angle (°)" } },
        y1: {
          min: 0.5,
          max: 6,
          position: "right",
          grid: { drawOnChartArea: false },
          ticks: {
            stepSize: 0.5, // Adjust step size for y-axis
          },
          title: { display: true, text: "Power (mW)" },
        },
        y2: {                          // 👈 NEW axis
          min: 0, max: 1200,
          position: "right",
          offset: true,                // push outside of y1
          grid: { drawOnChartArea: false },
          title: { display: true, text: "Irradiation (W/m²)" },
        }
      },
      plugins: {
        legend: {
          display: true,
          position: "top",
        },
        title: {
          display: true,
          text: "Solar Power",
        },
      },
    },
  });

  // Hour Wheel Slider Implementation (Hours Only)
  let currentHour = 11; // Default to 11:00
  const hourWheel = document.getElementById("hourWheel");

  let startY = 0;
  let isDragging = false;
  const scrollSensitivity = 30; // px to drag for 1 hour change

  // Create hour elements
  function createHourElements() {
    hourWheel.innerHTML = "";
    for (let i = 0; i < 24; i++) {
      const hourElement = document.createElement("div");
      hourElement.className = "hour-item";
      hourElement.textContent = String(i).padStart(2, "0");
      hourElement.dataset.hour = i;
      hourElement.addEventListener("click", () => {
        currentHour = i;
        updateHourDisplay();
      });
      hourWheel.appendChild(hourElement);
    }
  }

  function updateHourDisplay() {
    const hours = document.querySelectorAll(".hour-item");

    hours.forEach((hour) => {
      const hourValue = parseInt(hour.dataset.hour);
      const diff = Math.abs(hourValue - currentHour);
      const minDiff = Math.min(diff, 24 - diff);

      hour.className = "hour-item";

      if (hourValue === currentHour) {
        hour.classList.add("selected", "pos-0");
      } else if (minDiff === 1) {
        hour.classList.add("adjacent");
        if (
          hourValue === currentHour + 1 ||
          (currentHour === 23 && hourValue === 0)
        ) {
          hour.classList.add("pos-minus-1");
        } else {
          hour.classList.add("pos-1");
        }
      } else if (minDiff === 2) {
        hour.classList.add("distant");
        if (
          hourValue === currentHour + 2 ||
          (currentHour >= 22 && hourValue < 2)
        ) {
          hour.classList.add("pos-minus-2");
        } else {
          hour.classList.add("pos-2");
        }
      } else {
        hour.classList.add("hidden");
      }
    });
  }

  function changeHour(direction) {
    if (direction > 0) {
      currentHour = (currentHour + 1) % 24;
    } else {
      currentHour = currentHour === 0 ? 23 : currentHour - 1;
    }
    updateHourDisplay();
  }

  // Scroll wheel changes 1 hour per scroll step
  hourWheel.addEventListener("wheel", (e) => {
    e.preventDefault();
    if (e.deltaY > 0) {
      changeHour(1);
    } else {
      changeHour(-1);
    }
  });

  // Dragging logic for touch and mouse — exactly 1 hour change per 30px drag
  hourWheel.addEventListener(
    "touchstart",
    (e) => {
      startY = e.touches[0].clientY;
      isDragging = true;
    },
    { passive: true }
  );

  hourWheel.addEventListener(
    "touchmove",
    (e) => {
      if (!isDragging) return;

      e.preventDefault(); // stop page scrolling during drag

      const currentY = e.touches[0].clientY;
      const deltaY = startY - currentY;

      if (Math.abs(deltaY) > scrollSensitivity) {
        if (deltaY > 0) {
          changeHour(1); // ↑ drag increases hour
        } else {
          changeHour(-1); // ↓ drag decreases hour
        }
        startY = currentY; // reset for next increment
      }
    },
    { passive: false }
  );

  hourWheel.addEventListener(
    "touchend",
    () => {
      isDragging = false;
    },
    { passive: true }
  );

  hourWheel.addEventListener("mousedown", (e) => {
    startY = e.clientY;
    isDragging = true;
    hourWheel.style.cursor = "grabbing";
  });

  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;

    const currentY = e.clientY;
    const deltaY = startY - currentY;

    if (Math.abs(deltaY) > scrollSensitivity) {
      if (deltaY > 0) {
        changeHour(1);
      } else {
        changeHour(-1);
      }
      startY = currentY;
    }
  });

  document.addEventListener("mouseup", () => {
    isDragging = false;
    hourWheel.style.cursor = "default";
  });

  // Apply button functionality (Hour Only - minutes set to :00)
  document.querySelector(".apply-time").addEventListener("click", () => {
    const hour = currentHour;
    console.log("Selected Hour:", hour);

    // Allow only 07:00 to 19:00 inclusive
    if (hour < 7 || hour > 19) {
      alert("Please select a time between 07:00 and 19:00.");
      return;
    }

    const selectedTimeStr = `${hour.toString().padStart(2, "0")}:00`;

    // Always start from 09:00
    const startIndex = labels.indexOf("06:00");

    // Cutoff = selected hour index
    const cutoffIndex = labels.findIndex((label) => label === selectedTimeStr);

    // End = cutoffIndex (inclusive)
    const endIndex = cutoffIndex + 1;

    // Update chart data
    systemChart.data.labels = labels.slice(startIndex, endIndex);
    systemChart.data.datasets[0].data = angleData.slice(startIndex, endIndex);
    systemChart.data.datasets[1].data = powerData.slice(startIndex, endIndex);
    systemChart.data.datasets[2].data = irradiationData.slice(startIndex, endIndex);

    // Keep x-axis fixed 07:00 → 17:00
    systemChart.options.scales.x.min = "06:00";
    systemChart.options.scales.x.max = "19:00";

    systemChart.update();

    socket.emit("control_event", { command: "apply_time", value: hour });
  });

  // Cleaning button toggle functionality
  let isCleaningActive = false;
  const cleaningButton = document.querySelector(".cleaning");

  cleaningButton.addEventListener("click", () => {
    const hour = currentHour;

    if (!isCleaningActive) {
      // Starting cleaning
      if (hour >= 7 && hour <= 19) {
        alert("Cleaning cannot be performed between 07:00 and 19:00");
        return;
      }

      // Start cleaning
      isCleaningActive = true;
      cleaningButton.textContent = "Stop Cleaning";
      cleaningButton.classList.add("cleaning-active");
      alert("Cleaning initiated!");

      socket.emit("control_event", { command: "cleaning", value: 1 });
    } else {
      // Stop cleaning
      isCleaningActive = false;
      cleaningButton.textContent = "Initiate Cleaning";
      cleaningButton.classList.remove("cleaning-active");
      alert("Cleaning stopped!");

      socket.emit("control_event", { command: "cleaning", value: 0 });
    }
  });

  // Initialize hour wheel
  createHourElements();
  updateHourDisplay();

  // ===================== Start/Stop Chart Animation =====================
    // ===================== Start/Stop Chart Animation =====================
  const startButton = document.querySelector(".start-button-container button");
  let isRunning = false;
  let animationIndex = 0;
  let animationInterval = null;

  function resetChart() {
  animationIndex = 0;
  systemChart.data.labels = labels; // full axis stays visible
  systemChart.data.datasets[0].data = new Array(labels.length).fill(null);
  systemChart.data.datasets[1].data = new Array(labels.length).fill(null);
  systemChart.data.datasets[2].data = new Array(labels.length).fill(null); // 👈 reset irradiation
  systemChart.update();
}

  

  function startAnimation() {
  resetChart();

  animationInterval = setInterval(() => {
    if (animationIndex >= labels.length) {
      clearInterval(animationInterval);
      isRunning = false;
      startButton.textContent = "Start";
      startButton.classList.remove("stop");
      return;
    }

    const hour = labels[animationIndex];
    // Reveal next point
    systemChart.data.datasets[0].data[animationIndex] = angleData[animationIndex];
    systemChart.data.datasets[1].data[animationIndex] = powerData[animationIndex];
    systemChart.data.datasets[2].data[animationIndex] = irradiationData[animationIndex]; // 👈 NEW

    systemChart.update();

    const hourString = hour.split(":")[0];
    const hourValue = parseInt(hourString, 10);
    socket.emit("control_event", { command: "apply_time", value: hourValue });

    animationIndex++;
  }, 2500); // speed (ms per step)
}

  startButton.addEventListener("click", () => {
    if (!isRunning) {
      // --- Start ---
      isRunning = true;
      startButton.textContent = "End";
      startButton.classList.add("stop");
      startAnimation();
    } else {
      // --- End ---
      clearInterval(animationInterval);
      isRunning = false;
      startButton.textContent = "Start";
      startButton.classList.remove("stop");
      resetChart();
    }
  });





});
