document.addEventListener("DOMContentLoaded", () => {
  const socket = io({ transports: ["websocket"] });

  const rpmLabels = [
    2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22
  ];

  const powerData = [
    1000, 1200, 1500, 1700, 
    2000, 2500, 3000, 3500, 
    
    4000, 4500, 5000, 5500, 5500, 5500, 5500, 5500, 5500, 5500, 5500, 0, 0
  ];

  // Create Chart.js instance (start empty)
  const ctx = document.getElementById("windGraph").getContext("2d");
  const windChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: rpmLabels, // start empty
      datasets: [
        {
          label: "Power (kw)",
          data: [], // start empty
          borderColor: "rgb(54, 162, 235)",
          backgroundColor: "rgba(54, 162, 235, 0.2)",
          tension: 0.3,
          pointRadius: 3,
          pointBackgroundColor: "rgb(54, 162, 235)",
          fill: true,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 500,
      },
      scales: {
        x: {
          type: "category", // Use "category" for string labels!
          title: { display: true, text: "wind speed (m/s)" },
          ticks: {
            autoSkip: false, // Prevents Chart.js from skipping labels
          },
          display: true,
        },
        y: {
          min: 1000,
          max: 6500,
          title: {
            display: true,
            text: "Power (kw)",
          },
          ticks: {
            stepSize: 500, // Adjust step size for y-axis
          },
        },
      },
      plugins: {
        legend: {
          display: true,
          position: "top",
          
        },
        title: {
          display: true,
          text: "Wind Turbine",
        },
      },
    },
  });

  // Slider and Apply button
  const rpmSlider = document.getElementById("rpmSlider");
  const currentRpmValue = document.getElementById("currentRpmValue");
  const startButton = document.querySelector(".apply-rpm-btn");
  const stopButton = document.querySelector(".stop-rpm-btn");



  rpmSlider.addEventListener("input", (event) => {
    currentRpmValue.textContent = event.target.value;
  });

  // Apply button logic
  startButton.addEventListener("click", () => {
    const rpmValue = parseInt(rpmSlider.value);
    if (rpmValue === 21 || rpmValue === 22) {
    alert("Heavily wind");
    socket.emit("control_event", { command: "rpm", value: 0 });
    return;
  }
    updateChart(rpmValue);
    socket.emit("control_event", { command: "rpm", value: rpmValue });
  });

  stopButton.addEventListener("click", () => {
    const confirmed = window.confirm("Are you sure you want to stop the RPM?");
    if (confirmed) {
      console.log("Stopping RPM...");
      socket.emit("control_event", { command: "stop_rpm", value: 1 });
    } else {
      console.log("Stop canceled.");
    }
  });

  function updateChart(selectedRpm) {
    const cutoffIndex = rpmLabels.findIndex((rpm) => rpm === selectedRpm);

    if (cutoffIndex !== -1) {
      windChart.data.labels = rpmLabels.slice(0, cutoffIndex + 1);
      windChart.data.datasets[0].data = powerData.slice(0, cutoffIndex + 1);
    } else {
      windChart.data.labels = [];
      windChart.data.datasets[0].data = [];
    }

    windChart.update();
    
  }

  const autoStartBtn = document.querySelector(".start-button-container button");

let interval = null;
let isRunning = false;

function resetChart() {
  // Reset chart data
  windChart.data.datasets[0].data = new Array(rpmLabels.length).fill(null);
  windChart.update();

  // Reset button
  autoStartBtn.style.backgroundColor = "green";
  autoStartBtn.textContent = "Start";
  isRunning = false;
}

autoStartBtn.style.backgroundColor = "green";
autoStartBtn.style.color = "white";
autoStartBtn.textContent = "Start";

autoStartBtn.addEventListener("click", () => {
  if (!isRunning) {
    // Start animation
    isRunning = true;
    let i = 0;

    autoStartBtn.style.backgroundColor = "red";
    autoStartBtn.textContent = "End";

    // Prepare chart (empty data at start)
    windChart.data.labels = rpmLabels;
    windChart.data.datasets[0].data = new Array(rpmLabels.length).fill(null);
    windChart.update();

      interval = setInterval(() => {
      if (i < rpmLabels.length && rpmLabels[i] <= 23) {
        windChart.data.datasets[0].data[i] = powerData[i];
        windChart.update({
          duration: 400,
          easing: "easeOutQuart",
        });
	 socket.emit("control_event",{command: "rpm", value:rpmLabels[i] });
        i++;
      } else {
        clearInterval(interval);

        // ✅ Do NOT reset chart — keep final line
        autoStartBtn.style.backgroundColor = "green";
        autoStartBtn.textContent = "Start";
        isRunning = false;
      }
    }, 2500);

  } else {
    // End clicked midway → reset chart
    clearInterval(interval);
    resetChart();
  }
});

});
