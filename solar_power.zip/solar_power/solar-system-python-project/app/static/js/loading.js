document.addEventListener('DOMContentLoaded', () => {
    // The dashboard_url is a global variable set by the Flask template
    const dashboardUrl = '/dashboard';

    setTimeout(() => {
        window.location.href = dashboardUrl;
    }, 3000);
});