document.addEventListener("DOMContentLoaded", () => {
    const socket = io({ transports: ['websocket'] });

    const shutdownBtn = document.querySelector(".red_button button");
    const connectionText = document.getElementById("connection-status-text");
    const remoteRadio = document.getElementById("optionRemote");
    const plantRadio = document.getElementById("optionPlant");

    // Load status from local storage on page load
    const storedStatus = localStorage.getItem('esp_connection_status');
    if (storedStatus) {
        updateUI(storedStatus);
    }

    // Shutdown button
    shutdownBtn.addEventListener("click", () => {
        const confirmShutdown = confirm("Are you sure you want to shut down?");
        if (confirmShutdown) {
            console.log("Shutdown initiated...");
            socket.emit("control_event", { command: "shutdown", value: 1 });
        } else {
            console.log("Shutdown cancelled.");
        }
    });

    // Main listener for ESP32 status
    socket.on('esp_status', (data) => {
        console.log('ESP32 status:', data.status);
        // Store the status in local storage
        localStorage.setItem('esp_connection_status', data.status);
        // Update the UI
        updateUI(data.status);
    });

    // Listen for data updates from the ESP32
    socket.on("esp_data_update", (data) => {
        console.log("Data from ESP32 received:", data);
        try {
            // The data is already a parsed JSON object from the server
            // You can now directly access its properties
            const statusData = data;
            
            // Example: you can use other data points here to update your UI
            if (statusData.temperature) {
                console.log("Received temperature:", statusData.temperature);
                // Update a temperature display element
                // document.getElementById('temp-display').textContent = statusData.temperature;
            }
            if (statusData.humidity) {
                console.log("Received humidity:", statusData.humidity);
                // Update a humidity display element
                // document.getElementById('humidity-display').textContent = statusData.humidity;
            }
            
        } catch (e) {
            console.error("Failed to process data from ESP32:", e);
        }
    });

    // Helper function to update UI elements based on status
    function updateUI(status) {
        if (status === 'connected') {
            // connectionText.textContent = 'ESP Connected';
            // connectionText.style.color = 'green';
            plantRadio.checked = true;
            remoteRadio.checked = false;
        } else {
            // connectionText.textContent = 'ESP Disconnected';
            // connectionText.style.color = 'red';
            plantRadio.checked = false;
            remoteRadio.checked = false;
        }
    }
});