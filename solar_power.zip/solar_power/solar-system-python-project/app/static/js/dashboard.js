document.addEventListener('DOMContentLoaded', () => {
  const socket = io({transports: ['websocket']});
  const button = document.getElementById('start-button');

  // More divided time labels for smoother animation (~20 points)
  const times = [
    '07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00', '10:30',
    '11:00', '11:30', '12:00', '12:30', '13:00', '13:30', '14:00', '14:30',
    '15:00', '15:30', '16:00', '16:30', '17:00', '18:00', '19:00',
  ];

  // RPM values for wind chart (10 → 20 evenly spread)
  const rpms = [
    3,  4,  5,  6,  7,  8,  9,  10, 10.5, 11, 11.5, 12,
    13, 14, 15, 16, 17, 18, 19, 20, 21,   22, 23,
  ];

  // Smooth angle transition for solar chart
  const angles = [
    -45, -43, -40, -38, -35, -30, -25, -20, -15, -10, 0,   10,
    15,  20,  25,  28,  30,  25,  20,  15,  0,   -5,  -10,
  ];

  // Separate power arrays for solar and wind charts
  const powerSolar = [
    0.5, 1, 1.5, 2, 3,   3.5, 4, 4.5, 4.8, 5, 5,   5,
    5,   5, 5,   5, 4.8, 4.5, 4, 3,   2,   1, 0.6,
  ];

  const powerWind = [
    1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 2, 2.2, 2.5, 2.8, 3,  3.3,
    3.5, 4,   4.3, 4.5, 5,   5,   5, 5,   0.5, 0.5, 0.5
  ];

  const irradiationSolar = [
    100,  200,  300,  400,  600,  800, 900, 1000, 1100, 1150, 1200, 1200,
    1200, 1200, 1200, 1100, 1000, 800, 600, 400,  200,  100,  50,
  ];

  let solarChart, windChart;
  let animationInterval;
  let stepIndex = 0;

  function resetCharts() {
    stepIndex = 0;
    solarChart.data.datasets[0].data = new Array(times.length).fill(null);
    solarChart.data.datasets[1].data = new Array(times.length).fill(null);
    solarChart.data.datasets[2].data = new Array(times.length).fill(null);
    windChart.data.datasets[0].data = new Array(rpms.length).fill(null);
    solarChart.update();
    windChart.update();
  }

  function startAnimation() {
    resetCharts();

    animationInterval = setInterval(() => {
      if (stepIndex >= times.length) {
        clearInterval(animationInterval);

        // Change button back to "Start" when animation ends
        button.textContent = 'Start';
        button.classList.remove('end');
        button.classList.add('start');

        return;
      }

      // Update solar chart: angle and solar power
      solarChart.data.datasets[0].data[stepIndex] = angles[stepIndex];
      solarChart.data.datasets[1].data[stepIndex] = powerSolar[stepIndex];
      solarChart.data.datasets[2].data[stepIndex] = irradiationSolar[stepIndex];

      // Update wind chart: independent wind power values
      windChart.data.datasets[0].data[stepIndex] = powerWind[stepIndex];

      solarChart.update();
      windChart.update();

      const hourString = times[stepIndex].split(':')[0];
      const hour = parseInt(hourString, 10);
      const rpm = rpms[stepIndex];

      socket.emit('control_event', {command: 'apply_time', value: hour});
      socket.emit('control_event', {command: 'rpm', value: rpm});

      stepIndex++;
    }, 2500);  // update every 2000ms
  }

  button.addEventListener('click', () => {
    if (button.classList.contains('start')) {
      // Switch "Start" to "End"
      button.textContent = 'End';
      button.classList.remove('start');
      button.classList.add('end');
      startAnimation();

      socket.emit('control_event', {command: 'start_button', value: 1});
    } else {
      // Switch "End" to "Start"
      button.textContent = 'Start';
      button.classList.remove('end');
      button.classList.add('start');
      clearInterval(animationInterval);
      resetCharts();

      socket.emit('control_event', {command: 'start_button', value: 0});
    }
  });

  // Solar chart config (left)
  const systemGraphConfig = {
    type: 'line',
    data: {
      labels: times,
      datasets: [
        {
          label: 'Angle',
          data: new Array(times.length).fill(null),
          yAxisID: 'y',
          borderColor: 'rgb(40, 167, 69)',
          backgroundColor: 'rgba(40, 167, 69, 0.2)',
          tension: 0.3,
          pointRadius: 3,
          pointBackgroundColor: 'rgb(40, 167, 69)',
          fill: true,
        },
        {
          label: 'Power (kw)',
          data: new Array(times.length).fill(null),
          yAxisID: 'y1',
          borderColor: 'rgb(255, 99, 132)',
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          tension: 0.3,
          pointRadius: 3,
          pointBackgroundColor: 'rgb(255, 99, 132)',
          fill: false,
        },
        {
          label: 'Irradiation',
          data: new Array(times.length).fill(null),
          yAxisID: 'y2',
          borderColor: 'rgb(255, 205, 86)',
          backgroundColor: 'rgba(255, 205, 86, 0.2)',
          tension: 0.3,
          pointRadius: 3,
          pointBackgroundColor: 'rgb(255, 205, 86)',
          fill: false,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      scales: {
        x: {
          title: {display: true, text: 'Time (hours)'},
          min: '07:00',
          max: '19:00',
          ticks: {stepSize: 1},
          display: true,
        },
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          title: {display: true, text: 'Angle (degrees)'},
          min: -50,
          max: 50,
          ticks: {stepSize: 10},
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          title: {display: true, text: 'Power (mW)'},
          min: 0.5,
          max: 5.5,
          ticks: {stepSize: 0.2},
          grid: {drawOnChartArea: false},
        },
        y2: {
          type: 'linear',
          display: true,
          position: 'right',
          title: {display: true, text: 'Irradiation (W/m²)'},
          min: 0,
          max: 1300,
          ticks: {stepSize: 200},
          grid: {drawOnChartArea: false},
        },
      },
      plugins: {
        legend: {display: true, position: 'top'},
        title: {display: true, text: 'Solar'},
      },
    },
  };

  // Wind chart config (right) — X axis is RPM
  const config2 = {
    type: 'line',
    data: {
      labels: rpms,
      datasets: [
        {
          label: 'Power (mW)',
          data: new Array(rpms.length).fill(null),
          yAxisID: 'y',
          borderColor: 'rgb(255, 99, 132)',
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          tension: 0.3,
          pointRadius: 3,
          pointBackgroundColor: 'rgb(255, 99, 132)',
          fill: false,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      scales: {
        x: {
          title: {display: true, text: 'Wind Speed (m/s)'},
          min: 3,
          max: 23,
          ticks: {stepSize: 1},
        },
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          title: {display: true, text: 'Power (mW)'},
          min: 0.5,
          max: 6,
          ticks: {stepSize: 0.2},
        },
      },
      plugins: {
        legend: {display: true, position: 'top'},
        title: {display: true, text: 'Wind Mill'},
      },
    },
  };

  // Render charts
  const ctx = document.getElementById('graph1').getContext('2d');
  solarChart = new Chart(ctx, systemGraphConfig);

  const ctx2 = document.getElementById('graph2').getContext('2d');
  windChart = new Chart(ctx2, config2);
});
