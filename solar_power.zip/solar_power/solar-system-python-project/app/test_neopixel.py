import time
import board
import neopixel

# --- Configuration ---
LED_COUNT = 200          # Number of LEDs in your strip
LED_PIN = board.D12     # GPIO18 (PWM capable)
ORDER = neopixel.GRB    # NeoPixel color order

# Create NeoPixel object
pixels = neopixel.NeoPixel(
    LED_PIN, LED_COUNT, brightness=0.5, auto_write=False, pixel_order=ORDER
)

# --- Functions ---
def color_wipe(color, delay=0.1):
    """Light up each LED in sequence with given color"""
    for i in range(LED_COUNT):
        pixels[i] = color
        pixels.show()
        time.sleep(delay)

def rainbow_cycle(wait=0.05, iterations=1):
    """Cycle through a rainbow across the strip"""
    for j in range(256*iterations):
        for i in range(LED_COUNT):
            rc_index = (i*256//LED_COUNT + j) & 255
            pixels[i] = wheel(rc_index)
        pixels.show()
        time.sleep(wait)

def wheel(pos):
    """Generate rainbow colors across 0-255 positions"""
    if pos < 85:
        return (pos*3, 255-pos*3, 0)
    elif pos < 170:
        pos -= 85
        return (255-pos*3, 0, pos*3)
    else:
        pos -= 170
        return (0, pos*3, 255-pos*3)

# --- Main ---
try:
    while True:
        # Red wipe
        color_wipe((255, 0, 0))
        # Green wipe
        color_wipe((0, 255, 0))
        # Blue wipe
        color_wipe((0, 0, 255))
        # Rainbow cycle
        rainbow_cycle()

except KeyboardInterrupt:
    pixels.fill((0, 0, 0))
    pixels.show()
    print("\nExiting program, LEDs off")
