import board
import neopixel
import bisect

def map_value(x, in_min, in_max, out_min, out_max):
    """Linear mapping like Arduino map()"""
    return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)

# ------------------------------
# LED Strip Configuration
# ------------------------------
NUM_PIXELS_S = 217
NUM_PIXELS_W = 200          
PIN_APPLY_TIME = board.D10 
PIN_RPM = board.D12        
BRIGHTNESS = 0.9

time_points_solar = [8, 9, 10, 11, 12, 15, 16, 17]
pixel_percentages_solar = [20, 40, 60, 80, 100, 80, 40, 0]

time_points_rpm = [6, 8, 10, 12, 14, 15]
pixel_percentages_rpm = [0, 20, 40, 60, 80, 100]
def get_pixels_for_time_solar(current_hour: float) -> int:
    """Return number of NeoPixels ON at given hour (step-based)."""
    idx = bisect.bisect_right(time_points_solar, current_hour) - 1
    if idx < 0:
        return 0  # before first slot → all off
    return int((pixel_percentages_solar[idx] / 100) * NUM_PIXELS_S)

def get_pixels_rpm(current_rpm):
    idx = bisect.bisect_right(time_points_rpm, current_rpm) - 1
    if idx < 0:
        return 0  # before first slot → all off
    return int((pixel_percentages_rpm[idx] / 100) * NUM_PIXELS_W)

# Initialize NeoPixels
pixels_apply_time = neopixel.NeoPixel(
    PIN_APPLY_TIME, NUM_PIXELS_S, brightness=BRIGHTNESS, auto_write=False
)
pixels_rpm = neopixel.NeoPixel(
    PIN_RPM, NUM_PIXELS_W, brightness=BRIGHTNESS, auto_write=False
)

# ------------------------------
# Current LED counts
# ------------------------------
apply_time_count = 0
rpm_count = 0

# ------------------------------
# Control function
# ------------------------------
def neopixel_control(value, command_type):
    """
    value: numeric value for the command
    command_type: "apply_time" or "rpm"

    Updates the corresponding strip independently.
    Both strips can be updated simultaneously.
    """
    global apply_time_count, rpm_count

    if command_type == "apply_time":
        apply_time_count = value
    if command_type == "rpm":
        rpm_count = value

    # ------------------------------
    # Update both strips in one go
    # ------------------------------
    # Apply-time strip
    pixels_apply_time.fill((0, 0, 0))
    for i in range(get_pixels_for_time_solar(apply_time_count)):
        pixels_apply_time[i] = (255, 0, 0)  # Red
    pixels_apply_time.show()

    # RPM strip
    pixels_rpm.fill((0, 0, 0))
    num_rpm_pixels = get_pixels_rpm(rpm_count)
    for i in range(num_rpm_pixels):
        # Light from bottom: start from (NUM_PIXELS - 1) and go down
        bottom_index = NUM_PIXELS_W - 1 - i
        pixels_rpm[bottom_index] = (0, 0, 255)  # Blue
    pixels_rpm.show()
