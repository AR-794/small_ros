from flask import Flask, render_template, url_for
from flask_socketio import SocketIO
from neopixel_control import neopixel_control  # Assuming this is a custom module for controlling NeoPixels
import asyncio
import websockets
import threading
import json
import time
import os
import subprocess

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

# Keep track of connected ESP32 clients
connected_clients = set()
ws_loop = None

# ---------------- WebSocket server for ESP32 ----------------
async def ws_handler(websocket):
    """
    Handles a new connection from an ESP32 client.
    Adds the client to a set and listens for messages.
    Forwards received messages to the web frontend via SocketIO.
    """
    global ws_loop
    connected_clients.add(websocket)
    print("✅ ESP32 connected")
    
    # Emit connected status to web frontend
    socketio.emit('esp_status', {'status': 'connected'})

    try:
        async for message in websocket:
            try:
                data = json.loads(message)
                print("⬅️ Received from ESP32:", data)
                # Forward the received message to all connected web clients
                socketio.emit('esp_data_update', data)
            except json.JSONDecodeError:
                print("❌ Received non-JSON message from ESP32:", message)
    except websockets.exceptions.ConnectionClosedError as e:
        print("ESP32 disconnected:", e)
    except Exception as e:
        print("An error occurred with an ESP32 connection:", e)
    finally:
        connected_clients.remove(websocket)
        print("❌ ESP32 disconnected")
        # Check if there are still any connected clients before updating status
        if not connected_clients:
            socketio.emit('esp_status', {'status': 'disconnected'})

async def send_to_esp32(data):
    """
    Sends data to all currently connected ESP32 clients.
    """
    if connected_clients:
        msg = json.dumps(data)
        await asyncio.gather(*(client.send(msg) for client in connected_clients))
        print(f"➡️ Forwarded to ESP32: {data}")
    else:
        print("⚠️ No ESP32 connected to forward data")

# ---------------- Flask routes ----------------
@app.route('/')
def loading():
    dashboard_url = url_for('dashboard')
    return render_template('loading.html', dashboard_url=dashboard_url)

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/system_control')
def system_control():
    return render_template('system_control.html')

@app.route('/wind_control')
def wind_control():
    return render_template('wind_control.html')

@app.route('/settings')
def settings():
    # Old code reference (kept as comment)
    # threading.Thread(target=_check_esp_status_for_settings, daemon=True).start()
    return render_template('settings.html')

# Old code function (kept as comment)

def shutdown():
    print("Shutdown requested from frontend.")
    try:
        subprocess.Popen(['sudo', 'shutdown', '-h', 'now'])
        return 'Shutting down...', 200
    except Exception as e:
        print(f"Shutdown failed: {e}")
        return f"Shutdown failed: {e}", 500
    
def start_browser():
    try:
        time.sleep(5)
        env = os.environ.copy()
        env['DISPLAY'] = ':0'
        normal_user = 'energyplant'
        env['XAUTHORITY'] = f'/home/{normal_user}/.Xauthority'
        subprocess.Popen([
            'sudo', '-u', normal_user, 'firefox',
            '--no-sandbox',
            '--disable-infobars',
            '--kiosk',
            'http://localhost:5000'
        ], env=env)
    except Exception as e:
        print("Browser failed to launch:", e)


# ---------------- Receive frontend Socket.IO events ----------------
@socketio.on('control_event')
def handle_control_event(data=None):
    print(f"Received control_event: {data}")

    # Old code with neopixel control (kept as comment)
    if data['command'] == 'shutdown':
        print("Received shutdown event")
        shutdown()
    if data['command'] == 'start_button':
        if data['value'] == 0:
            print("Received start_button event")
            neopixel_control(0, "rpm")
            neopixel_control(0, "apply_time")
    if data['command'] == 'cleaning':
        print("Received cleaning event")
        neopixel_control(0, "rpm")
        neopixel_control(0, "apply_time")
    if data['command'] == 'stop_rpm':
        print("Received stop_rpm event")
        neopixel_control(0, "rpm")
    if data['command'] == 'apply_time':
        print("Received apply_time event")
        neopixel_control(data['value'], "apply_time")
    if data['command'] == 'rpm':
        print("Received rpm event")
        if(data['value'] < 20):
            neopixel_control(data['value'], "rpm")
        else:
            neopixel_control(0, "rpm")
   # The new asyncio-based forwarding logic
    if ws_loop and ws_loop.is_running():
        asyncio.run_coroutine_threadsafe(send_to_esp32(data), ws_loop)
    else:
        print("❌ WebSocket server loop is not running. Cannot forward data.")

# ---------------- Start WebSocket server in separate thread ----------------
def start_ws_server():
    """
    Starts the asyncio WebSocket server in a new thread.
    """
    global ws_loop

    async def server_main():
        global ws_loop
        ws_loop = asyncio.get_running_loop()
        server = await websockets.serve(ws_handler, "0.0.0.0", 8765)
        print("WebSocket server running on ws://0.0.0.0:8765")
        await server.wait_closed()

    asyncio.run(server_main())



if __name__ == "__main__":
    neopixel_control(0, "rpm")
    neopixel_control(0, "apply_time")

    threading.Thread(target=start_browser).start()
    threading.Thread(target=start_ws_server, daemon=True).start()
    socketio.run(app, host="0.0.0.0", port=5000, debug=False, allow_unsafe_werkzeug=True)
